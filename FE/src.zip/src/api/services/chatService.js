import axiosInstance from "../config/axios.js";

export const chatService = {
  // Tạo 1 cuộc hội thoại mới
  createConversation: () => axiosInstance.post("/chat/conversations"),

  // Lấy danh sách cuộc hội thoại 
  listConversations: () => axiosInstance.get("/chat/conversations"),

  // Lấy messages của 1 cuộc hội thoại
  getMessages: (conversationId) =>
    axiosInstance.get(`/chat/conversations/${conversationId}/messages`),

  // Gửi message theo conversationId 
  sendMessage: (conversationId, message, language = "vi") =>
    axiosInstance.post("/chat", { conversationId, message, language }),
  getSuggestions: () => axiosInstance.get("/chat/suggestions"),

  getChatAnalytics: (days = 7) => axiosInstance.get(`/admin/chat-analytics?days=${days}`),
};